#!/system/bin/sh
# 莫晨服务 - 开机自启脚本
# 由 KernelSU/Magisk 托管，彻底脱离终端，避免系统强杀

# 强制指定模块路径
MODDIR="/data/adb/modules/cufy5chu"

# 日志文件路径
LOG_FILE="/data/local/tmp/cufy5chu_postfs.log"

# 记录启动时间
echo "[$(date '+%Y-%m-%d %H:%M:%S')] 开机自启脚本开始执行" >> "$LOG_FILE"

# 修复权限（确保 service.sh 可执行）
chmod 755 "$MODDIR/service.sh"
chmod 755 "$MODDIR/api_handler.sh"
chmod -R 755 "$MODDIR/webroot"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] 权限修复完成" >> "$LOG_FILE"

# 延迟启动服务（避免系统刚开机时强杀后台进程）
(
  # 等待系统完全启动完成
  until [ "$(getprop sys.boot_completed)" = 1 ]; do
    sleep 1
  done
  # 再延迟 10 秒，确保系统资源充足
  sleep 10

  # 清理旧进程，避免端口冲突
  pkill -f "service.sh" 2>/dev/null
  pkill -f "busybox httpd" 2>/dev/null
  pkill -f "nc" 2>/dev/null
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] 旧进程清理完成" >> "$LOG_FILE"

  # 核心：用 setsid 启动服务，彻底脱离终端，永不出现 error 143
  setsid sh "$MODDIR/service.sh" >>/cache/cufy5chu.log 2>&1 &
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] 服务已启动（setsid 模式）" >> "$LOG_FILE"
) &

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 开机自启脚本主流程结束" >> "$LOG_FILE"
exit 0
