#!/system/bin/sh
# 莫晨服务一键后台启动脚本
# 用于手动启动或开机自启

# 强制获取 root 权限
if [ "$(id -u)" -ne 0 ]; then
    exec su -c "$0" "$@"
    exit 1
fi

# 配置路径
MODULE_PATH="/data/adb/modules/cufy5chu"
SERVICE_FILE="$MODULE_PATH/service.sh"
LOG_FILE="/cache/cufy5chu.log"

echo "[+] 正在启动莫晨服务（后台模式）..."

# 清理旧进程，避免端口冲突
echo "[*] 清理残留进程..."
pkill -f "service.sh" 2>/dev/null
pkill -f "httpd" 2>/dev/null
pkill -f "nc" 2>/dev/null
sleep 2

# 核心：用 setsid 彻底脱离终端，避免 error 143
echo "[*] 启动服务进程..."
setsid sh "$SERVICE_FILE" >> "$LOG_FILE" 2>&1 &

# 等待 3 秒后检查启动状态
sleep 3
if pgrep -f "service.sh" >/dev/null; then
    echo "✅ 服务启动成功，已后台运行"
    echo "   日志查看: tail -f $LOG_FILE"
else
    echo "❌ 服务启动失败，请检查日志: $LOG_FILE"
fi
