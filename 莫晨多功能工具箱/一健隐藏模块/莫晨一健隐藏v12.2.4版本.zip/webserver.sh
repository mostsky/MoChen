#!/system/bin/sh
[ "$(id -u)" -ne 0 ] && exec su -c "$0" "$@"

MODULE_PATH="/data/adb/modules/cufy5chu"
WEBROOT="$MODULE_PATH/webroot"
PORT="8080"
API_PORT="8081"

# 轻量杀旧进程
pkill -f "busybox httpd" 2>/dev/null
pkill -f "nc.*$API_PORT" 2>/dev/null
sleep 0.2

# 启动网页服务（轻量、不抢资源）
busybox httpd -u root -p 0.0.0.0:$PORT -h "$WEBROOT" -c "$MODULE_PATH/httpd.conf" 2>/dev/null

# API 接口（后台死循环但极低占用，不卡开机）
(
    cd "$WEBROOT"
    while true; do
        busybox nc -ll -p $API_PORT -e "$MODULE_PATH/api_handler.sh" 2>/dev/null
        sleep 1
    done
) &

echo "[+] 莫晨服务启动成功"
echo "    网页：http://设备IP:$PORT"
echo "    接口：http://设备IP:$API_PORT"
