#!/system/bin/sh
MODULE_PATH="/data/adb/modules/cufy5chu"
LOG_FILE="$MODULE_PATH/webroot/most_sky_run.log"

export PATH=/sbin:/system/bin:/system/xbin:/vendor/bin:/data/adb/modules/ksu/bin:/data/adb/ap/bin:$PATH

# 读取请求（避免变量名覆盖系统 PATH）
read -r METHOD REQUEST_PATH PROTO
while read -r line; do
  [ "$line" = $'\r' ] && break
done

# 获取 key 参数
KEY=$(echo "$REQUEST_PATH" | grep -o 'key=[^&]*' | sed 's/key=//')

# 跨域头 + 响应头
echo "HTTP/1.1 200 OK"
echo "Content-Type: text/plain"
echo "Access-Control-Allow-Origin: *"
echo ""

# 日志函数
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
  sync
}

echo "[INFO] 莫晨API接口运行中"
log "动作：$KEY"
log "当前执行用户：$(id)"
log "当前PATH：$PATH"

# 执行脚本函数（直接 root 执行，兼容所有版本）
run_script() {
  local s="$1"
  local d="$2"
  echo "[INFO] 执行：$d"
  log "执行：$s"
  chmod 755 "$s"
  
  log "=== 开始执行脚本：$s ==="
  log "脚本权限：$(ls -l "$s")"
  log "直接以 root 执行脚本"
  
  # 执行脚本并捕获所有输出
  sh "$s" >> "$LOG_FILE" 2>&1
  
  log "=== 脚本执行结束：$s ==="
  echo "[OK] $d"
  log "完成：$d"
}

# 匹配 key 并执行对应脚本
case "$KEY" in
run) run_script "$MODULE_PATH/webroot/main.sh" "一键执行" ;;
a) run_script "$MODULE_PATH/webroot/a.sh" "配置hma-oss" ;;
b) run_script "$MODULE_PATH/webroot/b.sh" "应用隐藏" ;;
c) run_script "$MODULE_PATH/webroot/c.sh" "配置usu路径" ;;
d) run_script "$MODULE_PATH/webroot/d.sh" "更新bl列表" ;;
e) run_script "$MODULE_PATH/webroot/e.sh" "keybox更新" ;;
f) run_script "$MODULE_PATH/webroot/f.sh" "MT路径配置修改" ;;
g) run_script "$MODULE_PATH/webroot/g.sh" "回收站关闭" ;;
# 新增：启动服务逻辑（key=h）
h)
  echo "[INFO] 正在启动后台服务..."
  log "启动服务：开始执行 service.sh"
  # 清理旧进程
  pkill -f "service.sh" 2>/dev/null
  pkill -f "busybox httpd" 2>/dev/null
  pkill -f "nc" 2>/dev/null
  sleep 1
  # 后台启动 service.sh（彻底脱离终端）
  setsid sh "$MODULE_PATH/service.sh" >>/cache/cufy5chu.log 2>&1 &
  echo "[OK] 启动服务 完成"
  log "启动服务：service.sh 已后台启动"
  ;;
clear)
  rm -f "$LOG_FILE"
  echo "[OK] 日志清空"
  log "日志清空"
  ;;
*)
  echo "[ERROR] 无效参数"
  log "无效参数"
  ;;
esac

echo "[OK] 执行完成"
