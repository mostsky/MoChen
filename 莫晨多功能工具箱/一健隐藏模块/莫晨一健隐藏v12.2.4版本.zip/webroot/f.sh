#!/system/bin/sh
# 莫晨一键过春秋环境清理 - 分区存储兼容版
# 修复：适配 Android 11+ 分区存储，避免 FUSE 拦截
# 固定路径：/data/user/0/org.frknkrc44.hma_oss/files/config.json

# ===================== 颜色定义 =====================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
GRAY='\033[0;37m'
NC='\033[0m'

# ===================== 环境检查 =====================
if [ "$(id -u)" -ne 0 ]; then
    echo -e "\n${RED}❌ 请使用ROOT权限运行！${NC}\n"
    exit 1
fi

clear

# ===================== 标题 =====================
echo -e "${PURPLE}=============================================${NC}"
echo -e "${CYAN}😘 莫晨隐藏应用配置工具 (分区存储兼容版) 😘${NC}"
echo -e "${PURPLE}=============================================${NC}"
echo -e "${YELLOW}🔧 酷安@莫晨        ${NC}"
echo -e "${PURPLE}=============================================${NC}"
echo -e "${YELLOW}📊 主要作用: 解决春秋发现风险应用、试图隐藏应用检测${NC}"
echo -e "${YELLOW}📁 配置路径: /data/user/0/org.frknkrc44.hma_oss/files/${NC}"
echo -e "${PURPLE}=============================================${NC}"

# ===================== 核心路径配置 =====================
CONFIG_PATH="/data/user/0/org.frknkrc44.hma_oss/files/config.json"
# 关键修改：使用底层真实路径，绕过 FUSE 分区存储限制
REAL_STORAGE="/data/media/0"
clean_dirs=(
    "${REAL_STORAGE}/Android/data"
    "${REAL_STORAGE}/Android/media"
    "${REAL_STORAGE}/Android/obb"
)

# ===================== 读取配置文件 =====================
echo -e "\n${BLUE}📄 正在读取配置文件...${NC}"
if [ ! -f "$CONFIG_PATH" ] || [ ! -s "$CONFIG_PATH" ]; then
    echo -e "${RED}❌ 错误: 未找到配置文件 -> $CONFIG_PATH${NC}"
    exit 1
fi

content=$(tr -d '\n\r\t ' < "$CONFIG_PATH" 2>/dev/null)
if [ -z "$content" ]; then
    echo -e "${RED}❌ 错误: 配置文件内容为空${NC}"
    exit 1
fi
echo -e "${GREEN}✅ 成功读取配置文件${NC}"

# ===================== 提取黑名单 =====================
echo -e "\n${BLUE}🔍 正在解析黑名单应用列表...${NC}"

block=$(echo "$content" | grep -oE '[^,{]*"[a-zA-Z0-9_]+List":\[[^]]*"isWhitelist":false[^]]*\]' 2>/dev/null)
if [ -z "$block" ]; then
    echo -e "${YELLOW}⚠️  未匹配到标准黑名单，尝试通用匹配...${NC}"
    block=$(echo "$content" | grep -oE '"appList":\[[^]]*\]' 2>/dev/null | head -n1)
fi

if [ -z "$block" ]; then
    echo -e "${RED}❌ 错误: 未在配置中找到应用列表块${NC}"
    exit 1
fi

best_list=$(echo "$block" | sed -E 's/^"[a-zA-Z0-9_]+List"://; s/\[//g; s/\]//g; s/"//g' 2>/dev/null)

if [ -z "$best_list" ] || [ "$best_list" = "null" ]; then
    echo -e "${YELLOW}⚠️  未解析到有效黑名单应用${NC}"
    exit 0
fi

app_count=$(echo "$best_list" | tr ',' '\n' | wc -l | tr -d ' ')
echo -e "${GREEN}✅ 成功解析到 ${YELLOW}$app_count${GREEN} 个黑名单应用${NC}"
sleep 1

# ===================== 清理逻辑（分区存储兼容版） =====================
echo -e "\n${PURPLE}=============================================${NC}"
echo -e "${CYAN}        🗑️  开始清理外部存储目录        ${NC}"
echo -e "${PURPLE}=============================================${NC}"

total_del=0

# 核心修复：使用底层路径 + 严格存在性检查
echo "$best_list" | tr ',' '\n' | while read -r pkg; do
    # 清洗包名
    pkg=$(echo "$pkg" | sed 's/^[ \t]*//;s/[ \t]*$//' | tr -cd 'a-zA-Z0-9._-')
    [ -z "$pkg" ] && continue

    echo -e "\n${BLUE}🔍 处理应用: ${CYAN}$pkg${NC}"
    del_count=0

    for base in "${clean_dirs[@]}"; do
        target="${base}/${pkg}"
        # 关键修复：严格检查目录是否存在，避免 ENOENT 错误
        if [ -d "$target" ] || [ -L "$target" ]; then
            echo -e "   ${GREEN}✅ 已清理: ${GRAY}$target${NC}"
            rm -rf "$target" >/dev/null 2>&1
            del_count=$((del_count + 1))
        fi
    done

    total_del=$((total_del + del_count))
done

# ===================== 结果总结 =====================
echo -e "\n${PURPLE}=============================================${NC}"
echo -e "${GREEN}🎉 清理任务完成！${NC}"
echo -e "${CYAN}📊 本次共清理目录: ${YELLOW}$total_del${NC}"
echo -e "${PURPLE}=============================================${NC}\n"

exit 0
