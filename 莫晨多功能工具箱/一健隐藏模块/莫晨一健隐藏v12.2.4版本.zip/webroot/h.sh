#!/system/bin/sh
if [ "$(id -u)" -ne 0 ]; then
    exec su -c "$0" "$@"
    exit 1
fi

MODULE_PATH="/data/adb/modules/cufy5chu"
WEBROOT="$MODULE_PATH/webroot"
PORT="8080"       # 网页端口
API_PORT="8081"   # API 接口端口（必须和网页不同）

# 彻底杀死旧进程
pkill -f "busybox httpd" 2>/dev/null
pkill -f "nc" 2>/dev/null
sleep 1

# 启动网页服务
busybox httpd -u root -p 0.0.0.0:$PORT -h "$WEBROOT" -c "$MODULE_PATH/httpd.conf"

# 启动 API 接口服务（真正执行脚本，无系统限制）
cd "$WEBROOT"
while true; do
  busybox nc -p $API_PORT -l -e "$MODULE_PATH/api_handler.sh"
done &

echo "[+] 莫晨服务启动成功"
echo "    网页：http://设备IP:$PORT"
echo "    接口：http://设备IP:$API_PORT"
