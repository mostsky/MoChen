#!/system/bin/sh
# 莫晨一键全套执行脚本：a b c d e f g + 关闭ADB/开发者选项 + 清除调试痕迹

echo "========================================"
echo "=== 莫晨一键全套执行 开始 ==="
echo "当前用户: $(id)"
echo "========================================"
echo ""

SCRIPT_DIR="/data/adb/modules/cufy5chu/webroot"

# 依次执行 a b c d e f g
for name in a b c d e f g; do
  shfile="${SCRIPT_DIR}/${name}.sh"
  echo "--- 执行 ${name}.sh ---"
  if [ -f "$shfile" ]; then
    chmod 755 "$shfile"
    sh "$shfile"
    echo "✅ ${name}.sh 执行完毕"
  else
    echo "⚠️  ${shfile} 不存在"
  fi
  echo ""
  sleep 1
done

echo "========================================"
echo "=== 关闭 ADB & 开发者选项 ==="
echo "========================================"

settings put global adb_enabled 0
settings put global development_settings_enabled 0
echo "✅ ADB 与开发者选项已关闭"

echo "========================================"
echo "=== 清除调试痕迹属性 ==="
echo "========================================"

setprop sys.usb.adb.disabled ""
setprop persist.security.adbinput ""
setprop persist.service.adb.enable ""
setprop persist.security.adbinstall ""
echo "✅ 调试痕迹已清理"

# 7. 解决春秋 Found property
# ==============================================
setprop persist.logd.size ""
setprop persist.logd.size.crash ""
setprop persist.logd.size.system ""
setprop persist.logd.size.main ""
echo "[OK] Found property 日志限制已清除"
echo ""
echo "========================================"
echo "🎉 全部任务执行完成"
echo "========================================"
