#!/system/bin/sh

# 通用全机型兼容版 - 不杀MT后台 + 删除MT2目录 + 关闭回收站 + 关闭删除提示
umask 0077

# 配置
TEMP_FILE="/data/local/tmp/mt2_config_$$.xml"

# 自动兼容路径
if [ -d "/data/data/bin.mt.plus" ]; then
  CONFIG_DIR="/data/data/bin.mt.plus"
else
  CONFIG_DIR="/data/user/0/bin.mt.plus"
fi

CONFIG_FILE="${CONFIG_DIR}/shared_prefs/bin.mt.plus_preferences.xml"

# 要写入的配置
MT2_PATH_LINE='    <string name="mt2_path">/storage/emulated/0/过春秋检测</string>'
ENABLE_RECYCLE_BIN_LINE='    <boolean name="enable_recycle_bin" value="false" />'
DEF_MOV_RECYCLE_BIN_LINE='    <boolean name="def_mov_recycle_bin" value="false" />'
DELETE_WARN_LINE='    <boolean name="delete_warn" value="false" />'
SHOW_DELETE_WARNING_LINE='    <boolean name="show_delete_warning" value="false" />'

# 失败退出
fail() {
  echo -e "\033[31m❌ 失败：$1\033[0m"
  rm -f "$TEMP_FILE"
  exit 1
}

# 必须ROOT
[ "$(id -u)" -eq 0 ] || fail "请使用ROOT权限执行"

# 检查文件
[ -f "$CONFIG_FILE" ] || fail "MT配置文件不存在，请先打开一次MT管理器"
[ -r "$CONFIG_FILE" ] && [ -w "$CONFIG_FILE" ] || fail "无法读写配置文件"

# 总行数
TOTAL_LINES=$(wc -l < "$CONFIG_FILE" 2>/dev/null)
[ -n "$TOTAL_LINES" ] && [ "$TOTAL_LINES" -ge 5 ] || fail "配置文件格式异常"

# 随机插入位置
RANDOM_LINE=$(( (RANDOM % (TOTAL_LINES - 3)) + 2 ))

# 清理旧项并写入
awk -v line="$RANDOM_LINE" \
    -v mt2="$MT2_PATH_LINE" \
    -v enable_recycle="$ENABLE_RECYCLE_BIN_LINE" \
    -v def_mov_recycle="$DEF_MOV_RECYCLE_BIN_LINE" \
    -v del_warn="$DELETE_WARN_LINE" \
    -v show_del_warn="$SHOW_DELETE_WARNING_LINE" '
function skip_line(s) {
    if (s ~ /<string name="mt2_path">/) return 1
    if (s ~ /<boolean name="recycle_bin_enable">/) return 1
    if (s ~ /<boolean name="enable_recycle_bin">/) return 1
    if (s ~ /<boolean name="def_mov_recycle_bin">/) return 1
    if (s ~ /<boolean name="delete_warn">/) return 1
    if (s ~ /<boolean name="show_delete_warning">/) return 1
    if (s ~ /<boolean name="recycle_bin_show_warning">/) return 1
    return 0
}
{ lines[NR] = $0 }
END {
    for (i=1; i<=NR; i++) {
        if (skip_line(lines[i])) continue
        print lines[i]
        if (i == line) {
            print mt2
            print enable_recycle
            print def_mov_recycle
            print del_warn
            print show_del_warn
        }
    }
}
' "$CONFIG_FILE" > "$TEMP_FILE" || fail "生成临时文件失败"

# 原子写入
cat "$TEMP_FILE" > "$CONFIG_FILE" 2>/dev/null
dd if="$TEMP_FILE" of="$CONFIG_FILE" >/dev/null 2>&1
sync

# 权限
chmod 600 "$CONFIG_FILE"
chown "$(stat -c %u:%g "$CONFIG_DIR")" "$CONFIG_FILE" 2>/dev/null

# 清理临时文件
rm -f "$TEMP_FILE"

# 删除旧MT2文件夹
echo -e "\033[33m🗑️ 正在删除旧MT2文件夹...\033[0m"
rm -rf "/storage/emulated/0/MT2" >/dev/null 2>&1
rm -rf "/sdcard/MT2" >/dev/null 2>&1

# 校验
grep -q 'name="mt2_path"' "$CONFIG_FILE" || fail "mt2_path写入失败"
grep -q 'enable_recycle_bin.*false' "$CONFIG_FILE" || fail "回收站关闭失败"
grep -q 'def_mov_recycle_bin.*false' "$CONFIG_FILE" || fail "默认移动到回收站关闭失败"
grep -q 'delete_warn.*false' "$CONFIG_FILE" || fail "删除警告关闭失败"
grep -q 'show_delete_warning.*false' "$CONFIG_FILE" || fail "显示删除预告关闭失败"

echo -e "\033[32m✅ 修改完成
🗑️ MT2文件夹已删除
♻️ 回收站已关闭
🔕 删除警告 & 删除预告已关闭\033[0m"
exit 0
