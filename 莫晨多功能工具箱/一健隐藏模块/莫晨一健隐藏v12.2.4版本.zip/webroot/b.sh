#!/system/bin/sh
# Zygisk Next 配置脚本
# 需求：仅还原挂载排除列表策略 + 开启匿名内存 + 打开实验性链接器

ZN_BIN="/data/adb/modules/zygisksu/bin/zygiskd"

# 1. 仅还原挂载排除列表策略
$ZN_BIN enforce-denylist just_umount

# 2. 开启匿名内存
$ZN_BIN memory-type anonymous

# 3. 打开实验性 Zygisk Next 链接器
$ZN_BIN linker builtin

echo "✅ Zygisk Next 配置已应用："
echo "  - 排除列表策略：仅还原挂载"
echo "  - 匿名内存：已开启"
echo "  - 实验性链接器：已开启"
