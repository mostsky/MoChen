#!/system/bin/sh
# 放到模块目录：/data/adb/modules/cufy5chu/service.sh

MODDIR=/data/adb/modules/cufy5chu
SRC="$MODDIR/webroot/config.json"
PKG="org.frknkrc44.hma_oss"
DEST="/data/user/0/$PKG/files/config.json"

# 等待系统完全启动（防SELinux拦截）
sleep 5

if [ -f "$SRC" ] && [ -d "/data/user/0/$PKG" ]; then
    # 复制并保持属性
    cp -af "$SRC" "$DEST"
    # 自动获取UID/GID（通用所有手机）
    UID=$(stat -c %u "/data/user/0/$PKG")
    GID=$(stat -c %g "/data/user/0/$PKG")
    chown "$UID:$GID" "$DEST"
    chmod 600 "$DEST"
fi
