#!/system/bin/sh
MODDIR="/data/adb/modules/cufy5chu"
LOG_FILE="/data/local/tmp/cufy5chu.log"

exec >> "$LOG_FILE" 2>&1
echo "[$(date)] service.sh 启动"

# 等待开机完成
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 0.3
done
sleep 2

# 关闭 ADB、开发者选项
if command -v settings >/dev/null 2>&1; then
    settings put global adb_enabled 0
    settings put global development_settings_enabled 0
    echo "[$(date)] 已关闭 adb & 开发者选项"
fi

# 清理临时文件
rm -rf "$MODDIR/apk/"* "$MODDIR/Cone/"* 2>/dev/null
echo "[$(date)] 临时文件清理完成"

# 尝试关闭 AVB
avbctl disable-verity 2>/dev/null
avbctl disable-verification 2>/dev/null
echo "[$(date)] AVB 操作完成"

# ==============================================
# 复制 HMA 配置文件 + 自动权限适配（全机型通用）
# ==============================================
HMA_PKG="org.frknkrc44.hma_oss"
HMA_DIR="/data/user/0/$HMA_PKG/files"
HMA_CONFIG="$HMA_DIR/config.json"
MODULE_CONFIG="$MODDIR/webroot/config.json"

if [ -f "$MODULE_CONFIG" ]; then
    # 先创建目录
    mkdir -p "$HMA_DIR" 2>/dev/null
    # 复制文件
    cp -af "$MODULE_CONFIG" "$HMA_CONFIG"
    # 自动获取应用 UID/GID 赋权，所有手机通用
    if [ -d "/data/user/0/$HMA_PKG" ]; then
        UID=$(stat -c %u "/data/user/0/$HMA_PKG")
        GID=$(stat -c %g "/data/user/0/$HMA_PKG")
        chown "$UID:$GID" "$HMA_CONFIG"
        chmod 600 "$HMA_CONFIG"
    fi
    echo "[$(date)] HMA 配置文件已从模块复制并赋权"
else
    echo "[$(date)] 模块内 config.json 不存在，跳过复制"
fi

# ==============================================
# 修改 HMA 配置内容
# ==============================================
if [ -f "$HMA_CONFIG" ]; then
    sed -i 's/莫晨隐藏环境v8.0.0/tpl_x/g' "$HMA_CONFIG" 2>/dev/null
    echo "[$(date)] HMA 配置内容已替换：莫晨隐藏环境v8.0.0 → tpl_x"
fi

# ==============================================
# 延迟启动 Web 服务
# ==============================================
(
    sleep 25
    pkill -f "httpd\|nc" 2>/dev/null
    setsid sh "$MODDIR/webserver.sh" >/dev/null 2>&1 &
    echo "[$(date)] Web服务已延迟启动"
) &

echo "[$(date)] service.sh 执行完毕"
exit 0
